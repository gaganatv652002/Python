file = open('myfile2.txt', 'a')
file.write('\n This is a new line of text.')

file.close()
