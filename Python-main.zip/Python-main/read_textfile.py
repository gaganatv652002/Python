file=open("myfile.txt","r")

print("Read function: ")
print(file.read())
print()
