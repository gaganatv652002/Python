x=int(input("Enter first number:"))
y=int(input("Enter second number:"))
sum=x+y
print("sum of two numbers is",str(sum))
