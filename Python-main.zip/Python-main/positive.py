num=int(input("Enter a number:"))
if(num==0):
    print("Zero")
elif(num<0):
    print("Negative number")
else:
    print("Positive number")
