b=int(input("Enter the base of the triangle:"))
h=int(input("Enter the height of the triangle:"))
area=b*h/2
print("Area of triangle is",area)
