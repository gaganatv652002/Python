mark1=int(input("Enter mark of subject1:"))
mark2=int(input("Enter mark of subject2:"))
mark3=int(input("Enter mark of subject3:"))
mark4=int(input("Enter mark of subject4:"))
mark5=int(input("Enter mark of subject5:"))
sum=mark1+mark2+mark3+mark4+mark5
avg=float((sum)/5)
print("Sum is ",sum)
print("Average is ",avg)
