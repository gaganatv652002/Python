for x in range(2,100,1):
    if(x%2==0):
        print(x)
