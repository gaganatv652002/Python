def longest_word(word):
    word=max(word,key_len)
    print("Longest word:",word)
    print("length of the longest word is:",len(word))
a=["book","calculator","pen","pencil","bag"]
longest_word(a)

