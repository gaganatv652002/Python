num1=int(input("Enter first number:"))
num2=int(input("Enter second number:"))
quotient=num1/num2
reminder=num1%num2
print("Quotient is ",quotient)
print("Reminder is ",reminder)
