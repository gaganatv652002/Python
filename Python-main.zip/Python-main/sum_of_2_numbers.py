x=4
y=2
sum=x+y
print("sum of two numbers is",str(sum))
