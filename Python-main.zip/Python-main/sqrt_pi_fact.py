import math

number = int(input("Enter a number: "))

print("Square root of",user_input,":",math.sqrt(number))
print("Factorial of",user_input,":",math.factorial(number))
print("Value of pi:",math.pi)
