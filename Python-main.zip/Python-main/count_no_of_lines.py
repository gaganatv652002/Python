file=open("myfile.txt","r")
d=file.readlines()
print("Number of lines:",len(d))
